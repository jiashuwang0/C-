﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;

namespace _3._12测试
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\94555\Desktop\3.12测试\数据库2.mdb;";

        private void button1_Click(object sender, EventArgs e)
        {


                if (textUserName.Text.Trim() == "")
                {
                    
                    MessageBox.Show("用户名不能为空！");
                    textUserName.Focus();
                    return;
                }
                else if (textPassword.Text.Trim() == "")
                {
                    MessageBox.Show("密码不能为空！");
                    textPassword.Focus();
                    return;
                }
                string sqlStr = "select user_id,user_pwd,user_type from [user] where user_id=@username";
                DataSet ds = new DataSet();
                OleDbConnection conn = new OleDbConnection(Con);
                conn.Open();
                OleDbCommand cmd = new OleDbCommand(sqlStr, conn);
                cmd.Parameters.Add(new OleDbParameter("@username", OleDbType.VarChar, 50));  //定义@username变量  varchar类型  50是字符串长度
                cmd.Parameters["@username"].Value = textUserName.Text;
                OleDbDataReader sdr = cmd.ExecuteReader();  // data获取select语句得到的表
                if (!sdr.Read())
                {
                    MessageBox.Show("用户名不存在请重新输入！");
                    textUserName.Text = "";
                    textPassword.Text = "";
                    textUserName.Focus();
                }
                else if (sdr["user_pwd"].ToString().Trim() == textPassword.Text.Trim())
                {
                    string user_type = sdr["user_type"].ToString().Trim();
                    MessageBox.Show("恭喜您已成功登录", "确定", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    主界面 f2 = new 主界面(user_type); f2.Show(); this.Hide(); 

                }
                else
                {
                    MessageBox.Show("密码错误！");;
                    textUserName.Text = "";
                    textPassword.Text = "";
                }

            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            注册界面 f2 = new 注册界面(this); this.Hide(); f2.Show();
        }

        private void textUserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
