﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3._12测试
{
    public partial class 分发交付部界面 : Form
    {
        public 分发交付部界面(主界面 f0)
        {
            InitializeComponent();
            f = f0;
        }
        private 主界面 f;
        private void button1_Click(object sender, EventArgs e)
        {
            f.Show();this.Close();
        }

        private void 分发交付管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 修订管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 编制管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 验证管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 修订管理ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void 分发交付部界面_Load(object sender, EventArgs e)
        {

        }
    }
}
