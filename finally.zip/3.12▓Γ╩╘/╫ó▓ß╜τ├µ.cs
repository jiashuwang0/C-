﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3._12测试
{
    public partial class 注册界面 : Form
    {
        public 注册界面(Login l0)
        {
            InitializeComponent();
            l = l0;
        }
        string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\94555\Desktop\3.12测试\数据库2.mdb;";
        private Login l;
        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string sqlStr = "select * from [user] where user_id=@username";
            DataSet ds = new DataSet();

            OleDbCommand cmd = new OleDbCommand(sqlStr, dbconn);
            cmd.Parameters.Add(new OleDbParameter("@username", OleDbType.VarChar, 50));  //定义@username变量  varchar类型  50是字符串长度
            cmd.Parameters["@username"].Value = textBox1.Text;
            OleDbDataReader sdr = cmd.ExecuteReader();  // data获取select语句得到的表
            if (!sdr.Read())
            {
                string x = textBox1.Text;
                string s = textBox2.Text;
                string Insert = "INSERT INTO [user]([user_id],[user_pwd]) values('" + x + "','" + s + "')";
                //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
                //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
                OleDbDataAdapter da = new OleDbDataAdapter();
                OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);
                int i = myCommand.ExecuteNonQuery();

                if (i > 0)
                {
                    MessageBox.Show("注册成功！");
                    l.Show(); this.Close();
                }//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功
            }
            else
            {
                MessageBox.Show("注册失败！用户已存在！");
            }
            dbconn.Close();
            
        }

        private void 注册界面_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            l.Show(); this.Close();
        }
    }
}
