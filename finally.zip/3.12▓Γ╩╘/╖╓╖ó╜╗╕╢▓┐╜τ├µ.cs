﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace _3._12测试
{
    public partial class 分发交付部界面 : Form
    {
        public 分发交付部界面(主界面 f0)
        {
            InitializeComponent();
            f = f0;
        }
        private 主界面 f;
        private void button1_Click(object sender, EventArgs e)
        {
            f.Show();this.Close();
        }
        string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\94555\Desktop\3.12测试\数据库.mdb;";
        private void 分发交付管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 修订管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 编制管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 验证管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 修订管理ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string x = textBox3.Text;

            string Insert = "INSERT INTO 分发交付部(分发需求) values('" + x + "')";
            //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
            //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 分发交付部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds

            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void 分发交付部界面_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string x = textBox1.Text;
          
            string Insert = "INSERT INTO 分发交付部(网络交付) values('" + x + "')";
            //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
            //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 分发交付部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds

            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            
            string s = textBox2.Text;
            string Insert = "INSERT INTO 分发交付部(纸质光盘交付) values('" + s + "')";
            //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
            //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 分发交付部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds

            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string x = textBox1.Text;
       
            string Insert = "INSERT INTO 分发交付部(记录归档) values('" + x + "')";
            //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
            //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 分发交付部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds

            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
