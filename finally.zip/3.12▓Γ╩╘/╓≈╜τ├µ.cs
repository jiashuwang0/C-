﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace _3._12测试
{
    public partial class 主界面 : Form
    {
        public 主界面()
        {
            InitializeComponent();
        }
        public 主界面(string UT)
        {
            InitializeComponent();
            user_type = UT;
        }
        string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\94555\Desktop\3.12测试\数据库.mdb;";
        private string user_type;
        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接
            if (textBox1.Text == "")
            {
                MessageBox.Show("技术出版物名称不能为空！");
            }
            else
            {
                string s = "'" + textBox1.Text + "'";//接受textBox1的字符串
                string Select = "SELECT * FROM 编辑部 WHERE 技术出版物名称 = " + s;
                //select *from 表名 where 字段名='字段值';*表示全表，从全表中
                OleDbDataAdapter inst = new OleDbDataAdapter(Select, dbconn);//只匹配满足条件的行




                DataSet ds = new DataSet();//临时存储
                inst.Fill(ds);//用inst填充ds
                dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
                dbconn.Close();//关闭连接
                MessageBox.Show(ds.Tables[0].Rows[0]["技术出版物编制人"].ToString());
                //这行代码可以展示ds中第一张表(Tables[0])第一行(Rows[0])["字段名"]的信息;在查找后可以用这种方式输出提示相关信息
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string x = textBox1.Text;
            string s = textBox2.Text;
            string Insert = "INSERT INTO 编辑部(技术出版物名称,技术出版物编制人) values('" + x + "','" + s + "')";
            //insert into 表名(字段1，字段2...)values('字段一内容'，'字段二内容')，上一行+用于字符串的连接，如果想用textBox传值，可用
            //string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            OleDbCommand myCommand = new OleDbCommand(Insert, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 编辑部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds

            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void button3_Click(object sender, EventArgs e)
        {

            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string s = "'" + textBox1.Text + "'", x = "'" + textBox2.Text + "'";
            string Update = "UPDATE 编辑部 SET 技术出版物名称 =" + x + " WHERE 技术出版物名称 = " + s;
            //update 表名 set 字段名='字段值' where 字段值='字段值';上一行代码执行后将所有studentName中的s替换为x
            OleDbCommand myCommand = new OleDbCommand(Update, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 编辑部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds
            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection dbconn = new OleDbConnection(Con);
            dbconn.Open();//建立连接

            string s = "'" + textBox1.Text + "'";//接受textBox1的字符串
            string Delete = "DELETE FROM 编辑部 WHERE 技术出版物名称 = " + s;
            //delete from 表名 where 字段名='字段值';以上代码执行后会将所有studentName为textbox中内容的行删除
            OleDbCommand myCommand = new OleDbCommand(Delete, dbconn);//执行命令
            myCommand.ExecuteNonQuery();//更新数据库，返回受影响行数;可通过判断其是否>0来判断操作是否成功

            OleDbDataAdapter inst = new OleDbDataAdapter("SELECT * FROM 编辑部", dbconn);//选择全部内容
            DataSet ds = new DataSet();//临时存储
            inst.Fill(ds);//用inst填充ds
            dataGridView1.DataSource = ds.Tables[0];//展示ds第一张表到dataGridView1控件
            dbconn.Close();//关闭连接
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void 主界面_Load(object sender, EventArgs e)
        {

        }


        private void 编制管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        if (this.user_type == "6" || this.user_type == "1")
        {
            编制部界面 f2 = new 编制部界面(this); this.Hide(); f2.Show();
        }
        else
        {

                MessageBox.Show("权限不足！");
            }

        }

        private void 验证管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        if (this.user_type == "6" || this.user_type == "2")
        {
            验证部界面 f2 = new 验证部界面(this); this.Hide(); f2.Show();
        }
        else
        {
                MessageBox.Show("权限不足！");
            }
        }

        private void 发布管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.user_type == "6" || this.user_type == "3")
            {
                发布部界面 f2 = new 发布部界面(this); this.Hide(); f2.Show();
            }
            else
            {
                MessageBox.Show("权限不足！");
            }
        }

        private void 分发交付管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.user_type == "6" || this.user_type == "4")
            {
                分发交付部界面 f2 = new 分发交付部界面(this); this.Hide(); f2.Show();
            }
            else
            {
                MessageBox.Show("权限不足！");
            }
        }

        private void 修订管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.user_type == "6" || this.user_type == "5")
            {
                修订部界面 f2 = new 修订部界面(this); this.Hide(); f2.Show();
            }
            else
            {
                MessageBox.Show("权限不足！");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
