﻿namespace _3._12测试
{
    partial class 分发交付部界面
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.编制管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.验证管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.分发交付管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修订管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修订管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(673, 158);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "返回主页面";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(168, 172);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(466, 145);
            this.dataGridView1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(169, 344);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "网络交付：";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(168, 389);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "纸质光盘交付：";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(308, 346);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(308, 389);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(168, 67);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "分发需求：";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(308, 67);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 7;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(673, 362);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "记录归档";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(671, 344);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "记录左侧textbox";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.编制管理ToolStripMenuItem,
            this.验证管理ToolStripMenuItem,
            this.分发交付管理ToolStripMenuItem,
            this.修订管理ToolStripMenuItem,
            this.修订管理ToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 25);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 编制管理ToolStripMenuItem
            // 
            this.编制管理ToolStripMenuItem.Name = "编制管理ToolStripMenuItem";
            this.编制管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.编制管理ToolStripMenuItem.Text = "编制管理";
            this.编制管理ToolStripMenuItem.Click += new System.EventHandler(this.编制管理ToolStripMenuItem_Click);
            // 
            // 验证管理ToolStripMenuItem
            // 
            this.验证管理ToolStripMenuItem.Name = "验证管理ToolStripMenuItem";
            this.验证管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.验证管理ToolStripMenuItem.Text = "验证管理";
            this.验证管理ToolStripMenuItem.Click += new System.EventHandler(this.验证管理ToolStripMenuItem_Click);
            // 
            // 分发交付管理ToolStripMenuItem
            // 
            this.分发交付管理ToolStripMenuItem.Name = "分发交付管理ToolStripMenuItem";
            this.分发交付管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.分发交付管理ToolStripMenuItem.Text = "发布管理";
            this.分发交付管理ToolStripMenuItem.Click += new System.EventHandler(this.分发交付管理ToolStripMenuItem_Click);
            // 
            // 修订管理ToolStripMenuItem
            // 
            this.修订管理ToolStripMenuItem.Name = "修订管理ToolStripMenuItem";
            this.修订管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.修订管理ToolStripMenuItem.Text = "分发交付管理";
            this.修订管理ToolStripMenuItem.Click += new System.EventHandler(this.修订管理ToolStripMenuItem_Click);
            // 
            // 修订管理ToolStripMenuItem1
            // 
            this.修订管理ToolStripMenuItem1.Name = "修订管理ToolStripMenuItem1";
            this.修订管理ToolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.修订管理ToolStripMenuItem1.Text = "修订管理";
            this.修订管理ToolStripMenuItem1.Click += new System.EventHandler(this.修订管理ToolStripMenuItem1_Click);
            // 
            // 分发交付部界面
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "分发交付部界面";
            this.Text = "分发交付部界面";
            this.Load += new System.EventHandler(this.分发交付部界面_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 编制管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 验证管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 分发交付管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修订管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修订管理ToolStripMenuItem1;
    }
}